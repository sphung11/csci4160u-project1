Double-click on A1.exe on Windows to run.

Arrow keys to move, space to jump.

Esc to quit.

Goal: Avoid snakes, find the treasure.